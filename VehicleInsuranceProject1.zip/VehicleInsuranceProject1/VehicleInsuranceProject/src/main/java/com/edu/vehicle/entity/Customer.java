package com.edu.vehicle.entity;

import javax.persistence.CascadeType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

//import com.edu.vehicle.entity.Vehicle;
//import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Customer {
	
//	add private data members
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)	
	private Long customerId;
	
	@Column(length=50)
	@NotBlank(message = "Please enter name")	
	private String customerName;
	
	@Column(unique=true, length=12)
	private Long customerAdharno;
	
	@Column(unique=true, length=10)
	private String customerPanno;
	
	@Column(unique=true, length=10)
	private Long customerPhone;
	
	@Column(unique=true, length=15)
	private String customerDrivinglisenceno;
	
//	add relationship 
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="insurance_Id",referencedColumnName="insuranceId")
	//@JsonIgnore
	private Vehicle vle;
	
//	getter setter methods for vehicle
	public Vehicle getVehicle() {
		return vle;
	}
	
	public void setVehicle(Vehicle vehicle) {
		this.vle=vehicle;
	}

//	non parameterized constructor
	public Customer() {
		super();
	}

//	parameterized constructor
	public Customer(Long customerId,
		 String customerName,
		Long customerAdharno, String customerPanno, Long customerPhone, String customerDrivinglisenceno) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAdharno = customerAdharno;
		this.customerPanno = customerPanno;
		this.customerPhone = customerPhone;
		this.customerDrivinglisenceno = customerDrivinglisenceno;
	}

//	getter setter methods
	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Long getCustomerAdharno() {
		return customerAdharno;
	}

	public void setCustomerAdharno(Long customerAdharno) {
		this.customerAdharno = customerAdharno;
	}

	public String getCustomerPanno() {
		return customerPanno;
	}

	public void setCustomerPanno(String customerPanno) {
		this.customerPanno = customerPanno;
	}

	public Long getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(Long customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerDrivinglisenceno() {
		return customerDrivinglisenceno;
	}

	public void setCustomerDrivinglisenceno(String customerDrivinglisenceno) {
		this.customerDrivinglisenceno = customerDrivinglisenceno;
	}

//	toString() method
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAdharno="
				+ customerAdharno + ", customerPanno=" + customerPanno + ", customerPhone=" + customerPhone
				+ ", customerDrivinglisenceno=" + customerDrivinglisenceno + "]";
	}
	
//	customer assign to vehicle
	public void customerAssignVehicle(Vehicle vehicle) {
		this.vle=vehicle;
		
	}
}