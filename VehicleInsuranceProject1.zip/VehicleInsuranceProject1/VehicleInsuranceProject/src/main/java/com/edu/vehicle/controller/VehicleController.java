package com.edu.vehicle.controller;

import java.sql.Date;



import java.util.List;
//import org.slf4j.Logger;

//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.edu.vehicle.controller.VehicleController;
import com.edu.vehicle.entity.Customer;
import com.edu.vehicle.entity.Vehicle;
import com.edu.vehicle.error.GlobalExceptionHandling;
import com.edu.vehicle.service.VehicleService;


@RestController 
@CrossOrigin(origins = "http://localhost:4200")
public class VehicleController {
	
	//Inject an object of VehicleService
	@Autowired
	private VehicleService vehicleService;
	
	
	                              
	 //http://localhost:portno/vehicles
	
	//add 
	@PostMapping("/vehicle")   //http://localhost:8889/vehicle
	public Vehicle addvehicle(@RequestBody Vehicle vehicle) {
		return vehicleService.addvehicle(vehicle);
		
	}
	
	//get  records by id
	@GetMapping("/getvehicle/(insuranceId}")  //http://localhost:8889/getvehicle/(insuranceId}
	public Vehicle getvehicleById(@PathVariable("insuranceId") Long insuranceId ) throws GlobalExceptionHandling {
		return vehicleService.getVehicleById(insuranceId);
		
	}
//		
		//delete
		@DeleteMapping("/deletevehicle/{insuranceId}")  //http://localhost:8889/deletevehicle/{insuranceId}
		public Vehicle DeletevehicleById(@PathVariable("insuranceId") Long insuranceId) throws GlobalExceptionHandling {
			return vehicleService.deletevehicleById(insuranceId);
		}
				
		//update 
		@PutMapping("/updatevehicle/{insuranceId}")  //http://localhost:8889/updatevehicle/{insuranceId}
		public Vehicle updatevehicleById (@PathVariable ("insuranceId") Long insuranceId,@RequestBody Vehicle vehicle) throws GlobalExceptionHandling {
			return vehicleService.UpdatevehicleById(insuranceId, vehicle);
			
		}
		
		//get all vehicles
		@GetMapping("/getAllVehicles")   //http://localhost:8889/getAllVehicles
		public List<Vehicle > getAllVehicles(){
			return vehicleService.getAllVehicles();
						
		}
		
//		get by vehicle name
		@GetMapping("/findvehicleByName/{vehicleName}")   //http://localhost:8889/findvehicleByName/{vehicleName}
		public List<Vehicle> findvehicleByName(@PathVariable("vehicleName")String vehicleName )
		{
			return vehicleService.findvehicleByName(vehicleName );
		}
		
		//find by date 
		@GetMapping("/findvehiclebetweentwodate/stardate/{sdate}/enddate/{edate}")  //http://localhost:8889/findvehiclebetweentwodate/stardate/{sdate}/enddate/{edate}
		public List<Vehicle>findvehiclebetweentwodate(@PathVariable("sdate")Date insuranceStartDate,@PathVariable("edate")Date insuranceEndDate){
			return vehicleService.findvehiclebetweentwodate(insuranceStartDate,insuranceEndDate);
			
		}

}
	
	
