import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './component/error/error.component';
import { LoginComponent } from './component/login/login.component';
import { HomeComponent } from './component/home/home.component';
import { CustomerComponent } from './component/customer/customer.component';
import { VehicleInsuranceComponent } from './component/vehicleInsurance/vehicle-insurance.component';
import { AddVehicleComponent } from './component/add-vehicle/add-vehicle.component';
import { AddCustomerComponent } from './component/add-customer/add-customer.component';
import { RouteGuardService } from './service/route-guard.service';
import { LogoutComponent } from './component/logout/logout.component';

const routes: Routes = [
  {path:'', component:HomeComponent},
  {path:'login', component:LoginComponent},
  {path:'customer', component:CustomerComponent,canActivate:[RouteGuardService]},
  {path:'addCustomer/:customerId', component:AddCustomerComponent,canActivate:[RouteGuardService]},
  {path:'vehicle-insurance', component:VehicleInsuranceComponent,canActivate:[RouteGuardService]},
  {path:'addVehicle/:insuranceId', component:AddVehicleComponent,canActivate:[RouteGuardService]},
  {path:'logout',component:LogoutComponent,canActivate:[RouteGuardService]},
  {path:'**', component:ErrorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
