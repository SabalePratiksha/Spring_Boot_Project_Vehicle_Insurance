import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HardcodedAuthenticationService } from 'src/app/service/hardcoded-authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  username = 'dhanashri';
  password = 'dhanashri123';
  invalidlogin = false;
  errormessage = 'please enter valid username and password!';

  constructor(private router: Router,private hardcodedAuthenocationService:HardcodedAuthenticationService) {}
  ngOnInit(): void {}

  handleLogin() {
    if(this.hardcodedAuthenocationService.authenticate(this.username,this.password)){
    // if (this.username === 'dhanashri' && this.password === 'dhanashri123') {
      //Redirect to welcome page
      this.router.navigate(['customer']);
    } else {
      this.invalidlogin = true;
    }
  }
}
